from django.db import models
from django.db.models.signals import pre_save, post_save
from django.conf import settings, global_settings
from .utils import unique_slug_generator # ai a minha slugga

User = global_settings.AUTH_USER_MODEL #fail save  pa nao importar o user_model se for faser uma usermodel

class BT(models.Model):
    uname = models.CharField(max_length=100, null=True)
    FK_dono = models.OneToOneField(User, on_delete=models.CASCADE, null=True)

#a pasta
class Pasta(models.Model):
    caminho = models.CharField(null=False, max_length=1000)
    slug = models.SlugField(null=True, blank=True)  # slug e um texto
    timestamp = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    tipo = models.CharField(max_length=100, default="Folder")

    def __str__(self):
        return self.caminho  # so para nao aparecer nomes estranhos se so invocar o objeto sem ".nome"

    @property  # adiciona pra gerar a slug
    def title(self):  # joga joga
        return self.caminho  # obj.title

#a pasta dentro da pasta
class Pasta_Pasta(models.Model):
    FK_pasta_parente = models.ForeignKey(Pasta, on_delete=models.CASCADE, related_name="parent_folder", null=False)
    FK_dono             = models.ForeignKey(User, on_delete=models.CASCADE)
    FK_pasta_filha   = models.ForeignKey(Pasta, on_delete=models.DO_NOTHING, related_name="child_folder")


# Create your models here.

#o ficheiro
class Ficheiro(models.Model):
    nome = models.CharField(max_length=1000)
    slug = models.SlugField(null=True, blank=True)  # slug e um texto
    timestamp = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    tipo = models.CharField(max_length=100, default="File")
    def __str__(self):
        return self.nome  # so para nao aparecer nomes estranhos se so invocar o objeto sem ".nome"

    @property  # adiciona pra gerar a slug
    def title(self):  # joga joga
        return self.nome  # obj.title

#o ficheiro da pasta tal
class Ficheiro_Pasta(models.Model):
    FK_dono           = models.ForeignKey(User, on_delete=models.CASCADE)
    FK_pasta_parente  = models.ForeignKey(Pasta, on_delete=models.CASCADE, null=False)
    FK_ficheiro_filho = models.ForeignKey(Ficheiro, on_delete=models.CASCADE, null=False)


class Medicao(models.Model):
    tipo      = models.CharField(max_length=50, default="medicao")
    unidade   = models.CharField(max_length=50, default="unidade")
    validade  = models.CharField(max_length=50, default="1semana")
    preservar_horas = models.BooleanField(default=False)

class Valor(models.Model): #valores sao expressoes em regime metrico, dpz o site converte
    valor      = models.FloatField(default=10000000)
    minimo     = models.FloatField(default=10000000)
    maximo     = models.FloatField(default=10000000)
    timestamp  = models.DateTimeField(auto_now_add=True)
    validade = models.DateTimeField(auto_now_add=False)
    etiqueta   = models.CharField(max_length=50, default="minuto")  # minuto para medicao ao minuto, hora para valor medio por hora, dia para valor medio diario
    FK_Medicao = models.ForeignKey(Medicao, on_delete=models.CASCADE)


