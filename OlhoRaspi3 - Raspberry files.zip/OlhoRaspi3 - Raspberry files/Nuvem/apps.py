from django.apps import AppConfig


class NuvemConfig(AppConfig):
    name = 'Nuvem'
