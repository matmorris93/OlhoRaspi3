from django.contrib import admin

# Register your models here.
from .models import Pasta, Pasta_Pasta, Ficheiro, Ficheiro_Pasta, Medicao, Valor, BT

admin.site.register(Pasta_Pasta)
admin.site.register(Pasta)
admin.site.register(Ficheiro_Pasta)
admin.site.register(Ficheiro)
admin.site.register(Medicao)
admin.site.register(Valor)
admin.site.register(BT)