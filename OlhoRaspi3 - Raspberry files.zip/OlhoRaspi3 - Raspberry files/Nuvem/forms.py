from django import forms
from django.contrib.auth import get_user_model
from .models import BT
User = get_user_model()

class RegForm(forms.ModelForm):
    #mailTag= forms.CharField(label="@bot.telegram caso queiras usar o bot", widget=forms.EmailField)
    passw1 = forms.CharField(label="Palavra-passe", widget=forms.PasswordInput)
    passw2 = forms.CharField(label="Confirme palavra-passe", widget=forms.PasswordInput)
    Bot_Telegram = forms.CharField(label="Username telegram", widget=forms.TextInput, required=False, empty_value="Nada")
    class Meta:
        model = User
        fields = ('username', 'email',)

    def pw_confirma(self):
        passw1 = self.cleaned_data.get("passw1")
        passw2 = self.cleaned_data.get("passw2")

        if passw1 and passw2 and passw1 != passw2:
            raise forms.ValidationError("As palavras-passe nao coincidem!")
        return passw2

    def save(self, commit=True):
        user = super(RegForm, self).save(commit=False)
        user.set_password(self.cleaned_data["passw1"])

        user.is_active = True #Depois mete isto a false, meti a true pq ao registar ja fica logo ativo, mas depois vou gerar algo q crie uma especie de sistema de convite q so ative aconta depois
        if commit:
            user.save()
            bot = BT()
            bot.uname = self.cleaned_data.get("Bot_Telegram")
            bot.FK_dono = user
            bot.save()
        return user



class UpdatePerfilForm(forms.ModelForm):
    #mailTag= forms.CharField(label="@bot.telegram caso queiras usar o bot", widget=forms.EmailField)
    un = ""
    username = forms.CharField(label="Novo username", widget=forms.TextInput, required=False, empty_value="ABARACARACAGARA")
    passw1 = forms.CharField(label="Nova Palavra-passe", widget=forms.PasswordInput, required=False)
    passw2 = forms.CharField(label="Confirme-a se modificou", widget=forms.PasswordInput, required=False)
    Bot_Telegram = forms.CharField(label="Novo Username telegram", widget=forms.TextInput, required=False, empty_value="Nada")
    confirm_pw = forms.CharField(label="Pw necessária para confirmar", widget=forms.PasswordInput, required=True)
    class Meta:
        model = User
        fields = ('username' ,'email',)


    def pw_confirma(self):

        passw1 = self.cleaned_data.get("passw1")
        passw2 = self.cleaned_data.get("passw2")
        if passw1 and passw2 and passw1 != passw2:
            raise forms.ValidationError("As palavras-passe nao coincidem!")
        return passw2

    def Confirma_uname(self, nom):
        self.un = nom
        return self.un

    def save(self, commit=True):
        user = super(UpdatePerfilForm, self).save(commit=False)
        user.set_password(self.cleaned_data["passw1"]) if self.cleaned_data["passw1"] else None
        if user.username == "ABARACARACAGARA":
            user.username = self.un
        user.is_active = True #Depois mete isto a false, meti a true pq ao registar ja fica logo ativo, mas depois vou gerar algo q crie uma especie de sistema de convite q so ative aconta depois
        if commit:
            user.save()
            if self.cleaned_data["Bot_Telegram"] != "Nada":
                bot = BT.objects.get(FK_dono=user)
                bot.uname = self.cleaned_data.get("Bot_Telegram")
                bot.save()
        return user


