import telepot, os, datetime, random, subprocess
import Nuvem.utils as utilidades
import _mysql, pydub
import VoiceRecognition_NOTGOOGLE as vr
import urllib.request
from sense_hat import SenseHat
from time import sleep
#NUMPY versao 1.14.2
medicoes = ["temp", "humidade", "pressao", "ruido", "luz", "pessoas"]
nomes = ["Temperatura", "Humidade", "Pressao", "Ruido", "Luz", "Pessoas"]

def getDBStuff():
    arai = []
    dictionario = None
    try:
        with open("CloudV1/DBData", 'r') as d:
            arai = d.readlines()
            NAME = arai[0].split(": ")[1][:-1]
            USER = arai[1].split(": ")[1][:-1]
            PASSWORD = arai[2].split(": ")[1][:-1]
            HOST = arai[3].split(": ")[1][:-1]
            PORT = arai[4].split(": ")[1][:-1]
            if not NAME or not USER or not PASSWORD or not HOST or not PORT:
                print("Algum campo nao foi especificado para a DB, vai ao ficheiro DBData na pasta CloudV1 e mete as coisas direito!")
                exit()
            return {
                "NAME": NAME,
                "USER": USER,
                "PASSWORD": PASSWORD,
                "HOST": HOST,
                "PORT": PORT,
            }
    except FileNotFoundError:
        filha = open("CloudV1/DBData", 'w')
        filha.write("NAME: \nUSER: \nPASSWORD: \nHOST: \nPORT: \nEND")
        filha.close()
        print("Nada foi especificado para a base de dados! Vai ao ficheiro DBData na pasta CloudV1 por favor e mete as coisas direito")
        exit()

def getBOTHash():
    ttt = '''Parece que não tens associado nenhum bot!
            Para criar um bot deves fazer os seguintes passos:
            1- Abre o telegrama e procura pelo botfather;
            2- Depois disso digite /newbot para criar o novo bot;
            3- Segue as instruções que o botfather te da;
            4- Passa o token que ele te gera para o ficheiro "leBOT" na pasta "ForBot";
            5- Done!'''
    try:
        with open("ForBot/leBOT", 'r') as b:
            hashbot = b.readline()
            if not hashbot:
                print(ttt)
                exit()
            return hashbot if hashbot[-1] != "\n" else hashbot[:-1]
    except FileNotFoundError:

        os.system("clear")
        niu = open("ForBot/leBOT", 'w')
        niu.close()
        print(ttt)
        exit()


bot = telepot.Bot(getBOTHash())
#mestre = "Ta7le33kGr4nge"
mestre = []
data_base = getDBStuff()
db = _mysql.connect(data_base["HOST"], data_base["USER"], data_base["PASSWORD"], data_base["NAME"])
db.query("SELECT * FROM Nuvem_bt")
pesquisa = db.store_result() #guarda o resultado da query
resultado = pesquisa.fetch_row(how=1, maxrows=0)
lenresultado = len(resultado)
for n in range(lenresultado):
    mestre.append(resultado[n]['uname'].decode('utf-8'))

sense = SenseHat()
def mysqlConnect():
    global db, data_base
    db.close()
    db = None
    new_con = _mysql.connect(data_base["HOST"], data_base["USER"], data_base["PASSWORD"], data_base["NAME"])
    sleep(2)
    db = new_con


siteAtivo = False
site = None
def StartSite():
    global site, siteAtivo
    siteAtivo = True
    with open(os.devnull, 'w') as devnull:
        site = subprocess.Popen(["python3", "/home/pi/Documents/ProjetoEstagio/CloudV1/manage.py", "runserver", "{}:8000".format(utilidades.getInternetP())],
                             stdout=devnull, stderr=subprocess.PIPE, shell=False)


piadas_secas = [
    "Porque a água foi presa? Porque matou a sede!",
    "Como é que os cereais acabam as relações? Nestum, sou eu!",
    "Porque o panado se divorciou? Porque a mulher não servia pa nada",
    "Qual o lugar que os taxistas não podem ir? Uberlândia no Brasil",
    "O que é um submarino com rodas? Um carnaval",
    "Qual o monumento favorito do thor? A torre de pizza, porque ela é torta",
    "Qual a semelhança dum padre para um martelo? Ambos pregam",
    "Para que serve um fiat panda? Pandar",
    "Porque é que os elefantes não pegam fogo? Porque são cinza",
    "O que diz uma banana suicida? Macacos me mordam",
    "Porque o Simba perdeu a virgindade? Porque veio lá o timon e pumba",
    "O que faz um informático na sanita? Multi mérdia",
    "Porque vende-se mais no dia dos namorados que no dia das mães? Porque mãe só temos uma!",
    "Qual é o bicho que anda com as patas? O pato",
    "O que foi fazer a galinha na igreja? Assistir a missa do galo",
    "Quais são os cereais favoritos do Drácula? Os de aveia",
    "Qual é o melhor chá para a calvice? Chá-peu",
    "Porquê as galinhas chocam? Porque não têm travões!",
    "Qual é a cor favorita das baterias de telemóvel? Rosa choque",
    "Qual é a estrada mais mal comportada? A marginal",
    "O que um prédio diz ao outro? Tens um andar jeitoso",
    "Porquê a térmita se divorciou? Porque comeu a secretária",
    "O que diz um cagalhão ao outro? Mas que vida de merda que tens!",
    "Conheces a piada do fotógrafo? Nao nao nao, ela não existe, não foi revelada!",
    "Se estiveres a me revelar para o Chester, manda-lhe um abraço",
    "Qual é o cúmulo da solidão? Tirar uma selfie à mão e postar no facebook no dia dos namorados!"
]
len_piadas_secas = len(piadas_secas)
instructiones = '''
    Instruções do bot (de observar que devem ser utilizadas como tags):
    
    "calor a" "is hot": Indica a temperatura no lugar onde o RPi está (exemplo: 'Ta calor aí?')
    
    "ar ta como" "how is the air": Indica a humidade e a pressao do lugar onde o rbpi está
    
    "barulho por ai" "is noisy": Indica o som
    
    "Ta escuro" "is dark": Indica a luminosidade
    
    "tempo em <lugar>" "weather at <lugar>" - Diz o tempo em Machico
    
    "manda uma piada"  "joke me": manda uma piada
    
    "Comunica o seguinte:<frase>" "talk this:": Diz ao raspberry para comunicar uma frase
    
    "messagehat this:<frase>" : o mesmo q acima mas para mandar msg no hat
    
    "quem te criou" "who created you": Foi Deus!
    
    "tas quente" "you hot": Retorna temperatura do RPi (exemplo: 'Entao tas quente?'
    
    "quem sou eu" "who am i": Retorna o nome do user falando com o bot
    
    "teu uptime" "your uptime": Da o uptime
    
    "teu ip" "you ip" "you protocol": Da o ip do RPi se ligado na net
    
    "teu disco" "you storage": retorna aspectos do armazenamento do disco
    
    "tudo bem contigo" "are you fine": retorna de forma simplificada problemas com o rb caso existam
    
    "data hoje" "today": Da o resultado da data de hoje junto com as horas (do sistema)
    
    "teu cpu" "you brain": manda as cenas da cpu
    
    "meu quarto" "my room": diz se ta alguem no quarto
    
    "reconnect": Reconecta a bd se nao receber msg do grafico
    
    "run site" : So pode ser usado uma vez e serve para iniciar o site
    
    "temperatura di", "temperatura sem", "temperatura ho", "humidade di", "humidade sem", "humidade ho",
    'pressão di, "pressão sem", "pressão ho", "ruido di", "ruido sem", "ruido ho", "luz di", "luz sem", "luz ho",

    
    'Retorna ficheiro html com os graficos relativos as mediçoes tomadas pelo RPi (exemplo: Manda-me o ruido semanal)  '
    -Detalhe: podes pedir a unidade que queres o grafico, e podes falar em ingles tags como "this hour", "in hours", "in days",
    so nao mostra os graficos das pessoas (por acrescentar no futuro...)
    
    "gera relatório" "gera relatorio" "generate report": gera relatório em pdf
    -Detalhe: podes especificar as coisas a incluir no pdf, por exemplo:
        ."Tudo" "all": Mete tudo
        .1 - "temperatura" ;
        .2 -"humidade" ;
        .3 -"pressão" ;
        .4 -"ruido";
        .5 -"luz" ;
        .6 -"pessoas" ;
 
    
    "<pedido> fala por voz" "<pedido> in voice": fala o q pediste por voz (menos os graficos)
    
    Agora que ja tens tudo manda-me alguma mensagem.
'''




def Lista_de_Unidades(db):
    texto_pesquisa = "SELECT tipo, unidade, validade, preservar_horas FROM Nuvem_medicao"
    db.query(texto_pesquisa)
    pesquisa = db.store_result()
    resultado = pesquisa.fetch_row(how=1, maxrows=0)
    listinha = {}
    for n in resultado:
        #n["unidade"].decode('utf-8')
        chave = n["tipo"].decode('utf-8')
        unidade = ""
        try:
            unidade = n["unidade"].decode('utf-8')
        except UnicodeDecodeError:
            unidade = n["unidade"].decode('ISO-8859-1') #por causa do simbolo º
        validade = n["validade"].decode('utf-8')
        preservar_horas = int(n["preservar_horas"])
        listinha.update({chave : [unidade, validade, preservar_horas]})
    return listinha

#Da conta da mensagem e efetua a devida instrucao
def Instrucoes_Caso_Text(msg, chatID, God="ywvw"):
    texto = "Nao percebi... digite 'ajuda-me' para lista de comandos!"
    if "calor a" in msg or "is hot" in msg:
        aru, ut = utilidades.LeitorAtual("Temperatura", 'ºC')

        if "Kelvin" in msg or "kelvin" in msg:
            aru = "K"
        elif "fahrenheit" in msg or "Fahrenheit" in msg:
            aru = "ºF"
        else:
            aru = "C"

        if float(ut) < 20:
            texto = "Não, ta fresquinho ({} graus {}) ".format(utilidades.conversor(aru, ut), aru)
        elif float(ut) >= 20 and float(ut) < 30:
            texto = "Não, ta ameno ({} graus {}) ".format(utilidades.conversor(aru, ut), aru)
        else:
            texto = "Alto forno primaço ({} graus {}) ".format(utilidades.conversor(aru, ut), aru)

        #bot.sendMessage(566328240, texto)
    elif "/start" in msg:
        texto = "Fala aí compadre!"
    elif "manda uma piada" in msg or "joke me" in msg:
        texto = piadas_secas[random.randint(0, len_piadas_secas-1)]
    elif "teus mestres" in msg:
        if God == "Ta7le33kGr4nge":
            texto = "Meus mestres:\n"
            for n in mestre:
                texto += n
                texto += "\n"

    elif "ta escuro" in msg or "is dark" in msg:
        pe, pa = utilidades.LeitorAtual("Luminosidade", "lx")
        if pe < 100:
            texto = "Sim, ta escuro cá dentro, cerca de {}lm".format(pa)
        else:
            texto = "Parece que não, cerca de {}lm".format(pa)

    elif "meu quarto" in msg or "my room" in msg:
        pe, lu = utilidades.LeitorAtual("Pessoas", "p")
        if pe == 0:
            texto = "Quarto vazio"
        else:
            texto = "{} pessoa(s) la dentro".format(pe)
    elif "ar ta como" in msg or "how is the air" in msg:
        aru, ut = utilidades.LeitorAtual("Humidade", 'percent')
        ura, p = utilidades.LeitorAtual("Pressão", "hPa")
        if float(ut) < 30:
            texto = "O ar ta bem seco, cerca de {}%".format(ut)
        elif float(ut) >= 30 and float(ut) < 60:
            texto = "O ar ta o que ta, cerca de {}%".format(ut)
        elif float(ut) >= 60 and float(ut) < 90:
            texto = "O ar ta húmido, cerca de {}%".format(ut)
        else:
            texto = "O ar ta bem húmido, cerca de {}%".format(ut)
        texto += ", com pressão de {} hPa".format(p)
    elif "barulho por ai" in msg or "is noisy" in msg:
        aru, ut = utilidades.LeitorAtual("Ruído", 'dB')
        if float(ut) < 50:
            texto = "Não, ta silencioso, cerca de {} decibeis".format(ut)
        elif float(ut) >= 50 and float(ut) < 70:
            texto = "Tá algum ruído sim, cerca de {} decibeis".format(ut)
        elif float(ut) >= 70 and float(ut) < 90:
            texto = "Tá alto estrondo, cerca de {} decibeis".format(ut)
        else:
            texto = "Nem venhas senão ficas surdo, tao {} decibeis".format(ut)

    elif "quem te criou" in msg or "who created you" in msg:
        texto = "Foi Ta7le33kGr4nge quem me criou, inspirado pela graça de Deus!"

    elif "comunica o seguinte:" in msg or "talk this:" in msg:
        utilidades.fala(msg.split("comunica o seguinte:")[1]) if "comunica o seguinte:" in msg else utilidades.fala(msg.split("talk this:")[1])
        texto = "Ja disse isso a eles!"
        #bot.sendMessage(566328240, texto)
    elif "messagehat this:" in msg:
        sense.show_message(msg.split("messagehat this:")[1])
        texto = "Ja disse isso a eles pelo HAT!"

    elif "tas quente" in msg or "you hot" in msg:
        tempi = utilidades.getCPUtemp()
        if tempi < 50:
            texto = "Tou normal, a {}ºC de temperatura".format(tempi)
        elif tempi >= 50 and tempi < 65:
            texto = "Tou um pouco quente, a {}ºC de temperatura".format(tempi)
        else:
            texto = "Quentissimo, a {}ºC de temperatura".format(tempi)
    elif "who am i" in msg or "quem sou eu" in msg:
        texto = "És o {}".format(God)
        #bot.sendMessage(566328240, texto)
    elif "raspberry_logo" in msg:
        bot.sendPhoto(chatID, open("rbpi.jpg", "rb"))
    elif "teu uptime" in msg or "your uptime" in msg:
        uti = utilidades.getUpTime()
        texto = "{} dias, {} horas, {} minutos e {} segundos!".format(uti[0], uti[1], uti[2], uti[3])
        #bot.sendMessage(566328240, texto)
    elif "teu ip" in msg or "you ip" in msg or "you protocol" in msg:
        texto = "O meu ip é:{}".format(utilidades.getInternetP())
    elif "teu disco" in msg or "you storage" in msg:
        texto = "usado: {}\n livre: {}\n total: {} Uso: {}%".format(utilidades.getDiskSpaces("used"),
                                                            utilidades.getDiskSpaces("free"),
                                                            utilidades.getDiskSpaces(
                                                                "total"),
                                                            utilidades.getDiskSpaces(
                                                                "pused"))
        #bot.sendMessage(566328240, texto)
    elif "temperatura " in msg or "temperature " in msg:
        pesquisa_text = "SELECT * FROM Nuvem_valor WHERE FK_Medicao_id = (SELECT id from Nuvem_medicao where tipo  = 'temp') AND etiqueta = '{}'{}"
        unidade = "ºC"
        ficheiro = "ForBot/l{}t.html"
        pediu_grafico_da_hora = False

        if "di" in msg or "in hours" in msg:
            pesquisa_text = pesquisa_text.format('hora', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("d")
        elif "sem" in msg or "in days" in msg:
            pesquisa_text = pesquisa_text.format('dia', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("w")
        else:
            pesquisa_text = pesquisa_text.format('minuto', "")
            ficheiro = ficheiro.format("h")
            pediu_grafico_da_hora = True

        if "Kelvin" in msg or "kelvin" in msg:
            unidade = "K"
        elif "fahrenheit" in msg or "Fahrenheit" in msg:
            unidade = "ºF"



        db.query(pesquisa_text)
        pesquisa = db.store_result()
        resultado = pesquisa.fetch_row(how=1, maxrows=0)  # fetcha como dict
        if pediu_grafico_da_hora:
            utilidades.last_Hour_stats(unidade, "Temperatura", resultado, True)
        else:
            utilidades.minmedmax_LastDay_or_Week(unidade, "Temperatura", resultado, True)
        try:
            bot.sendDocument(chatID, open(ficheiro, "rb"))
            texto = "GRAFICOU"
        except FileNotFoundError:
            texto = "Não há dados para mandar!"


    elif "humidade " in msg or "humidity " in msg:
        pesquisa_text = "SELECT * FROM Nuvem_valor WHERE FK_Medicao_id = (SELECT id from Nuvem_medicao where tipo  = 'humidade') AND etiqueta = '{}'{}"
        unidade = "%"
        ficheiro = "ForBot/l{}h.html"
        pediu_grafico_da_hora = False

        if "di" in msg or "in hours" in msg:
            pesquisa_text = pesquisa_text.format('hora', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("d")
        elif "sem" in msg or "in days" in msg:
            pesquisa_text = pesquisa_text.format('dia', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("w")
        else:
            pesquisa_text = pesquisa_text.format('minuto', "")
            ficheiro = ficheiro.format("h")
            pediu_grafico_da_hora = True




        db.query(pesquisa_text)
        pesquisa = db.store_result()
        resultado = pesquisa.fetch_row(how=1, maxrows=0)  # fetcha como dict
        if pediu_grafico_da_hora:
            utilidades.last_Hour_stats(unidade, "Humidade", resultado, True)
        else:
            utilidades.minmedmax_LastDay_or_Week(unidade, "Humidade", resultado, True)
        try:
            bot.sendDocument(chatID, open(ficheiro, "rb"))
            texto = "GRAFICOU"
        except FileNotFoundError:
            texto = "Não há dados para mandar!"



    elif "pressão " in msg or "pressure " in msg:
        pesquisa_text = "SELECT * FROM Nuvem_valor WHERE FK_Medicao_id = (SELECT id from Nuvem_medicao where tipo  = 'pressao') AND etiqueta = '{}'{}"
        unidade = "mBar"
        ficheiro = "ForBot/l{}p.html"
        pediu_grafico_da_hora = False

        if "di" in msg or "in hours" in msg:
            pesquisa_text = pesquisa_text.format('hora', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("d")
        elif "sem" in msg or "in days" in msg:
            pesquisa_text = pesquisa_text.format('dia', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("w")
        else:
            pesquisa_text = pesquisa_text.format('minuto', "")
            ficheiro = ficheiro.format("h")
            pediu_grafico_da_hora = True


        if "inHg" in msg or "inhg" in msg:
            unidade = "inHg"
        elif "hPa" in msg or "hpa" in msg:
            unidade = "hPa"
        elif "Bar" in msg or "bar" in msg and "mBar" not in msg and "mbar" not in msg:
            unidade = "Bar"
        elif "atm" in msg:
            unidade = "atm"

        db.query(pesquisa_text)
        pesquisa = db.store_result()
        resultado = pesquisa.fetch_row(how=1, maxrows=0)  # fetcha como dict
        print(unidade)
        if pediu_grafico_da_hora:
            utilidades.last_Hour_stats(unidade, "Pressão", resultado, True)
        else:
            utilidades.minmedmax_LastDay_or_Week(unidade, "Pressão", resultado, True)
        try:
            bot.sendDocument(chatID, open(ficheiro, "rb"))
            texto = "GRAFICOU"
        except FileNotFoundError:
            texto = "Não há dados para mandar!"

    elif "ruido " in msg or "noise " in msg or "ruído " in msg:
        pesquisa_text = "SELECT * FROM Nuvem_valor WHERE FK_Medicao_id = (SELECT id from Nuvem_medicao where tipo  = 'ruido') AND etiqueta = '{}'{}"
        unidade = "dB"
        ficheiro = "ForBot/l{}r.html"
        pediu_grafico_da_hora = False

        if "di" in msg or "in hours" in msg:
            pesquisa_text = pesquisa_text.format('hora', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("d")
        elif "sem" in msg or "in days" in msg:
            pesquisa_text = pesquisa_text.format('dia', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("w")
        else:
            pesquisa_text = pesquisa_text.format('minuto')
            ficheiro = ficheiro.format("h")
            pediu_grafico_da_hora = True


        if "sone" in msg:
            unidade = "sone"

        db.query(pesquisa_text)
        pesquisa = db.store_result()
        resultado = pesquisa.fetch_row(how=1, maxrows=0)  # fetcha como dict
        if pediu_grafico_da_hora:
            utilidades.last_Hour_stats(unidade, "Ruído", resultado, True)
        else:
            utilidades.minmedmax_LastDay_or_Week(unidade, "Ruído", resultado, True)
        try:
            bot.sendDocument(chatID, open(ficheiro, "rb"))
            texto = "GRAFICOU"
        except FileNotFoundError:
            texto = "Não há dados para mandar!"

    elif "luz " in msg or "luminosity " in msg:
        pesquisa_text = "SELECT * FROM Nuvem_valor WHERE FK_Medicao_id = (SELECT id from Nuvem_medicao where tipo  = 'luz') AND etiqueta = '{}'{}"
        unidade = "lx"
        ficheiro = "ForBot/l{}l.html"
        pediu_grafico_da_hora = False

        if "di" in msg or "in hours" in msg:
            pesquisa_text = pesquisa_text.format('hora', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("d")
        elif "sem" in msg or "in days" in msg:
            pesquisa_text = pesquisa_text.format('dia', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("w")
        else:
            pesquisa_text = pesquisa_text.format('minuto', " ORDER BY timestamp DESC limit 19")
            ficheiro = ficheiro.format("h")
            pediu_grafico_da_hora = True


        if "Lumen" in msg or "lumen" in msg:
            unidade = "lm"
        if "candela" in msg or "Candela" in msg:
            unidade = "cd"


        db.query(pesquisa_text)
        pesquisa = db.store_result()
        resultado = pesquisa.fetch_row(how=1, maxrows=0)  # fetcha como dict
        if pediu_grafico_da_hora:
            utilidades.last_Hour_stats(unidade, "Luz", resultado, True)
        else:
            utilidades.minmedmax_LastDay_or_Week(unidade, "Luz", resultado, True)
        try:
            bot.sendDocument(chatID, open(ficheiro, "rb"))
            texto = "GRAFICOU"
        except FileNotFoundError:
            texto = "Não há dados para mandar!"

    elif "data hoje" in msg or "today" in msg:
        texto = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        #bot.sendMessage(chatID, texto)

    elif "teu cpu" in msg or "you brain" in msg:
        cpu = utilidades.getCPUFreq()
        texto = "Frequência atual: {} - ({}%)  mínimo: {}   máximo: {}  -- (medições em megaHertz)". format(cpu[0], cpu[1], cpu[2], cpu[3])
        #bot.sendMessage(566328240, texto)

    elif 'ajuda-me' in msg or "help" in msg:
        texto = instructiones
        #bot.sendMessage(566328240, instructiones)

    elif "tempo em " in msg or "weather at " in msg:
        lugar_para_leitura = "Mundo"
        try:
            lugar = msg.split("tempo em ")[1] if "tempo em" in msg else msg.split("weather at ")[1]
            lugar_para_leitura = lugar
            lugar = lugar.lower().replace(" ", "-").replace("ã", "a").replace("á", "a").replace("ó", "o").replace("õ", "o").replace("é", "e").replace("í", "i").replace("â", "a")
            lugar = lugar.replace("-invoice", "").replace("-in-voice", "").replace("-fala-por-voz", "")
            lugar_para_leitura = lugar_para_leitura.replace("invoice", "").replace("in voice", "").replace("fala por voz", "")
            pedido = urllib.request.urlopen("https://www.tempo.pt/{}.htm".format(lugar))
            htmlbytes = pedido.read()
            mega_string = htmlbytes.decode('utf-8')

            inicio_string_index = mega_string.find('title="Temp.')
            string_index = mega_string[inicio_string_index: inicio_string_index+100]
            temperatura = string_index.split(">")[1].split("&deg")[0]

            inicio_string_index = mega_string.find('Atmos')
            string_index = mega_string[inicio_string_index: inicio_string_index + 100]
            atmosfera = string_index.split(">")[1].split("</dd")[0].replace("&iacute;", "i").replace("&eacute;", "e").replace("&aacute;", "a").replace("&uacute", "u")

            texto = "Tempo em {}: {} graus Celcius de temperatura, com {} ".format(lugar_para_leitura, temperatura, atmosfera)
        except:
            texto = "Alguma coisa se passou, nao consegui buscar a meteorologia para o lugar referido!"

    elif "reconnect" in msg:
        bot.sendMessage(chatID, "Reconectando à base de dados...")
        mysqlConnect()
        sleep(2)
        texto = "BD Reconectada com sucesso!"

    elif "reinicia" in msg or "reboot" in msg:
        if God == 'Ta7le33kGr4nge':
            bot.sendMessage(chatID, "Dando reboot... Manda-me 'you on?' para te notificar mal acorde")
            os.system("sudo reboot")
        else:
            texto = "Acesso negado! Somente o superAdmin pode fazer isto (el creador)"

    elif "you on?" in msg:
        if God == 'Ta7le33kGr4nge':texto = "Já estou ligado e pronto para a guerra sr {}, so tem um problema: não sei iniciar processos, o leitor e o site vais ter q fazer manualmente!".format(God)

    elif "run site" in msg:
        texto = "Este serviço ainda nao se encontra ativo"

    elif "run arduino" in msg:
        texto = "Este serviço ainda nao se encontra ativo"

    elif "tudo bem contigo" in msg or "are you fine" in msg:
        texto = utilidades.Tudo_Bem_Contigo(True)
    elif "gera relatório" in msg or "gera relatorio" in msg or "generate report" in msg:
        texto = "REPORTOU"
        tipo = "Relatorio manual"
        lista_de_unidades = Lista_de_Unidades(db)
        quem_incluir = []
        prefacio = {
            "automaticamente": False,
            "tipo": tipo,
            "quem_gerou": "{} via BOT".format(God),
        }
        if "tudo" in msg or "all" in msg:
            quem_incluir = [m for m in medicoes]
        else: #["temp", "humidade", "pressao", "ruido", "luz", "pessoas"]
            if "1" in msg :
                quem_incluir.append("temp")
            if "2" in msg :
                quem_incluir.append("humidade")
            if "3" in msg :
                quem_incluir.append("pressao")
            if "4" in msg :
                quem_incluir.append("ruido")
            if "5" in msg:
                quem_incluir.append("luz")
            if "6" in msg:
                quem_incluir.append("pessoas")

        if len(quem_incluir) == 0:
            texto= "Necessitas de escolher o que vais por nesse relatório! - Digite 'ajuda-me'"
        else:

            dados = []
            feedback = "Preparando o teu relatório com dados relativos a "
            if len(quem_incluir) ==1:
                feedback+= quem_incluir[0] + "."
            else:
                for i in range(len(quem_incluir)):
                    feedback += quem_incluir[i]
                    feedback += ", " if i != len(quem_incluir)-2 and i != len(quem_incluir)-1 else " e "
                feedback +="."

            bot.sendMessage(chatID, feedback)
            for n in quem_incluir:
                validade = lista_de_unidades[n][1]
                unidade  = lista_de_unidades[n][0]
                preservar_horas = lista_de_unidades[n][2]
                texto_pesquisa = "SELECT * FROM Nuvem_valor WHERE etiqueta != 'minuto' and FK_Medicao_id in (SELECT id from Nuvem_medicao where tipo='{}') order by timestamp".format(
                    n)
                db.query(texto_pesquisa)
                pesquisa = db.store_result()
                resultado = pesquisa.fetch_row(how=1, maxrows=0)
                dados.append([nomes[medicoes.index(n)], validade, unidade, preservar_horas,
                              resultado])


            nome = datetime.datetime.now().strftime("%Y-%m-%d") + ".pdf"
            caminho = utilidades.PreparaPDF(dados, prefacio, nome, True)
            texto+="---{}".format(caminho)
            bot.sendDocument(chatID, open(caminho, "rb"))



    if "fala por voz" in msg or "in voice" in msg or "invoice" in msg and texto != "GRAFICOU":
        utilidades.fala(texto, True)
        bot.sendVoice(chatID,open("ForBot/VoiceSounds/BotTalk.mp3", "rb"))
    else:

        if texto != "GRAFICOU":
            if "REPORTOU" in texto:
                os.system("rm {}".format(texto.split("---")[1]))
                texto = "Aí está o teu relatório!"
            bot.sendMessage(chatID, texto)
        else:
            os.system("rm ForBot/*.html")




def Decode_Voz(msg, chatID):
    bot.sendMessage(chatID, "Ok, xame analisar o que disseste...")
    bot.download_file(msg["file_id"], "ForBot/VoiceSounds/mensagem.ogg")
    sounda = pydub.AudioSegment.from_ogg("ForBot/VoiceSounds/mensagem.ogg")
    soundaa = sounda.set_channels(1)
    sound = soundaa.set_frame_rate(16000)
    sound.export("ForBot/VoiceSounds/mensagem.wav", format="wav")
    os.system("rm ForBot/VoiceSounds/mensagem.ogg")
    rr = vr.decode_phrase("ForBot/VoiceSounds/mensagem.wav")

    cleanText = "Tu disseste:" + " ".join(o for o in rr)
    cleanText = cleanText.replace("<s>", "").replace("</s>", "").replace("<sil>", "").replace("(2)", "").replace("(3)", "").replace("  ", " ").replace("   ", " ")
    bot.sendMessage(chatID, cleanText)
    Instrucoes_Caso_Text(cleanText, chatID)

def Que_Faz_O_Bot(msg):
    chatID = msg["from"]["id"]
    if msg["from"]["username"] in mestre:
        if "text" in msg.keys():
            print("Foi mensagem de texto")
            Instrucoes_Caso_Text(msg.get("text", None).lower(), chatID,msg["from"]["username"])
        elif "voice" in msg.keys():
            print("Foi mensagem de voz")
            Decode_Voz(msg["voice"], chatID)
        elif "photo" in msg.keys():
            print("Foi uma foto")

    else:
        bot.sendMessage(chatID, "Nao te conheço!")

if __name__ =='__main__':
    print("Bot preparado...")
    sleep(3)
    os.system('clear')
    print("Detalhe: para saber se o bot esta bem ve se nao da muitos tracebacks de rajada. Se isso acontecer, verifica se o token esta bem escrito!")
    bot.message_loop(Que_Faz_O_Bot)
    while True:
        pass
