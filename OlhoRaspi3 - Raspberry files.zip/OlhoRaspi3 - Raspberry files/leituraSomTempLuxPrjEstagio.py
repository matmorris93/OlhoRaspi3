'''
Script leitor de som, falta integrar ao arduino
Funcionamento:
    Primeiro ele vai fazer uma leitura minuto a minuto, buscando varios valores durante o minuto depois fazendo a media e inserindo na base de dados
    Depois ele vai verificar se ja s epassou uma hora para fazer o valor medio horario
    Depois faz o mesmo so que para o dia e para o mes

    obs: antes tinha uma query gigante com joins, tudo teve q ser tirado
    pois o raspberry demorava MUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUITO tempo a fazer a bendita query
'''

import random, datetime, _mysql, sys, serial, serial.tools.list_ports, calendar, os
from time import sleep
from sense_hat import SenseHat
from Nuvem.utils import LeitorAtual, getDiskSpaces, PreparaPDF

#Conjunto de arrays que guarda os valores que vai buscando durante cada minuto para depois fazer a estimativa
avgTemp, avgHumid, avgPres, avgRuido, avgLuz, avgPessoas = [], [], [], [], [], []

def getDBStuff():
    arai = []
    dictionario = None
    try:
        with open("CloudV1/DBData", 'r') as d:
            arai = d.readlines()
            NAME = arai[0].split(": ")[1][:-1]
            USER = arai[1].split(": ")[1][:-1]
            PASSWORD = arai[2].split(": ")[1][:-1]
            HOST = arai[3].split(": ")[1][:-1]
            PORT = arai[4].split(": ")[1][:-1]
            if not NAME or not USER or not PASSWORD or not HOST or not PORT:
                print("Algum campo nao foi especificado para a DB, vai ao ficheiro DBData na pasta CloudV1 e mete as coisas direito!")
                exit()
            return {
                "NAME": NAME,
                "USER": USER,
                "PASSWORD": PASSWORD,
                "HOST": HOST,
                "PORT": PORT,
            }
    except FileNotFoundError:
        filha = open("CloudV1/DBData", 'w')
        filha.write("NAME: \nUSER: \nPASSWORD: \nHOST: \nPORT: \nEND")
        filha.close()
        print("Nada foi especificado para a base de dados! Vai ao ficheiro DBData na pasta CloudV1 por favor e mete as coisas direito")
        exit()


def Lista_de_Unidades(db):
    texto_pesquisa = "SELECT tipo, unidade, validade, preservar_horas FROM Nuvem_medicao"
    db.query(texto_pesquisa)
    pesquisa = db.store_result()
    resultado = pesquisa.fetch_row(how=1, maxrows=0)
    listinha = {}
    for n in resultado:
        #n["unidade"].decode('utf-8')
        chave = n["tipo"].decode('utf-8')
        unidade = ""
        try:
            unidade = n["unidade"].decode('utf-8')
        except UnicodeDecodeError:
            unidade = n["unidade"].decode('ISO-8859-1') #por causa do simbolo º
        validade = n["validade"].decode('utf-8')
        preservar_horas = int(n["preservar_horas"])
        listinha.update({chave : [unidade, validade, preservar_horas]})
    return listinha

class Arduino():
    def __init__(self):
        self.connectArduino()

    def getArduino(self):  # procura pelo endereco do (primeiro) arduino e joga
        for porta in serial.tools.list_ports.comports():
            try:
                return porta.device if ("Arduino" in porta.manufacturer) else True
            except TypeError:
                return "/nao/encontrei/nada"  # Pasta tonta so pa la em baixo dar o exception

    def connectArduino(self):  # vai conectar o arduino com base na porta que recebeu
        detectou = False
        porta = ""
        print("Tentando conectar-se a arduino...")
        while detectou is not True:  # vai ir lupando ate detectar o arduino
            try:
                porta = self.getArduino()
                if porta != None:
                    detectou = True
                    self.arduinoIR = serial.Serial(porta, 9600)
                    print("Arduino detectado na porta {}".format(porta))
                    sleep(1)


            except serial.serialutil.SerialException:
                pass  # nao detectou, nao faz mal, vai detectar na hora certa!
        print("Arduino conectado com sucesso na porta {}".format(porta))
        sleep(1)
        print("Estabilizando leitores...")
        sleep(15)

    def leSerial(self):
        try:
            while True:
                if (self.arduinoIR.in_waiting is not 0):  # Se estiver dados a espera no serial killer
                    myData = self.arduinoIR.readline().decode("utf-8")  # vou ler os bytes e converter para string
                    myData = myData.strip("\r\n")  # removo os caracteres chatos de la
                    if myData != None:
                        return myData

        except serial.serialutil.SerialTimeoutException:
            return False  # falhou qualquer coisa, reconectar please
        except IOError:
            return False  # falhou qualquer coisa, reconectar please
        except AttributeError:
            return False

#Le os valores recebidos pelo arduino e passa como inteiros ou floats
def Leitor(sensor1, sensor2):
    pressao, ruido, humidade =  round(sensor2.get_pressure(), 1), round(sensor2.get_orientation()['roll'], 1), round(sensor2.get_humidity(), 1)
    temperatura, luz, pessoas = 0,0,0
    leitura_arduino = sensor1.leSerial()

    if leitura_arduino is False:
        print("Perdida conexao com o arduino, tentando reconectar...")
        sensor1.connectArduino()
    else:
        temp = None
        lumi = None
        pess = None
        while not temp or not lumi or not pess: #enquanto da coisas estupidas vai ir rebuscando
            try:
                temp = leitura_arduino.split(";")[0].split("T:")
            except:
                temp = None
            try:
                lumi = leitura_arduino.split(";")[1].split("L:")
            except:
                lumi = None
            try:
                pess = leitura_arduino.split(";")[2].split("P:")
            except:
                pess = None
        try: #por vezes derivado a alteracoes fisicas como voltagem e corrente o arduino falha, isto e so uma medida
            temperatura = int(temp[1])
        except:
            lixo, temperatura = LeitorAtual("Temperatura", 'ºC')
            temperatura = float(lixo)
        try:
            luz = int(lumi[1])
        except:
            lixo, luz = LeitorAtual("Luminosidade", "lux")
            luz = float(lixo)
        try:
            pessoas = int(pess[1])
        except:
            lixo, pessoas = LeitorAtual("Pessoas", "p")
            pessoas = float(lixo)
        if luz < 0 : luz = 0
        print(temperatura, humidade, pressao, ruido, luz, pessoas)
    sleep(4)
    return temperatura, humidade, pressao, ruido, luz, pessoas
    



#Escreve em ficheiros os valores em tempo real (Nao os dos graficos!) para fazer a leitura em tempo real
def escritor(t,h,p,r,l,pe):
    with open("ValAtuais/Temperatura", "w") as f:
        f.write(t)
    with open("ValAtuais/Humidade", "w") as f:
        f.write(h)
    with open("ValAtuais/Pressao", "w") as f:
        f.write(p)
    with open("ValAtuais/Ruido", "w") as f:
        f.write(r)
    with open("ValAtuais/Luminosidade", "w") as f:
        f.write(l)
    with open("ValAtuais/Pessoas", "w") as f:
        f.write(pe)


#Limpa da base de dados toda a tralha, isto e...
def limpador(db, what):
    if what == 'minuto': #Se quero limpar tralha de minutos
        #  Devo pesquisar por todas as entradas com a etiqueta 'minuto' onde seu timestamp nao corresponde a hora atual
        db.query("DELETE FROM Nuvem_valor WHERE etiqueta = 'minuto' AND HOUR(timestamp) != HOUR(current_time)")
        #  e apago, assim nao aparecem dados de minuto que nao correspondem a hora atual de medicao
    elif what == 'hora': #Se quero limpar as horas
        #apaga tudo q nao seja deste dia para nao aparecer na cena do ultimo dia
        db.query("DELETE FROM Nuvem_valor WHERE etiqueta = 'hora' AND DAY(timestamp) != DAY(current_date) AND FK_Medicao_id in (SELECT id from Nuvem_medicao where preservar_horas = 0)")

        sleep(3)
        # Parte do apagar conforme a validade, ira apagar de hora em hora
        db.query("SELECT id, validade FROM Nuvem_medicao")
        pesquisa = db.store_result()  # guarda o resultado da query
        resultado = pesquisa.fetch_row(how=1, maxrows=0)  # guarda todos os valores q sai da query
        len_resultado = len(resultado)

        for n in range(len_resultado):
            db.query("DELETE FROM Nuvem_valor WHERE NOW() >= validade AND FK_Medicao_id ={}".format(resultado[n].get("id", None)))


    elif what == 'semana': #apaga tudo q nao seja desta smana para q nao apareca no ultima semana
        db.query("DELETE from Nuvem_valor WHERE WEEK (timestamp) != WEEK(current_date)  AND YEAR(timestamp) = YEAR(current_date) AND NOW() >= validade AND etiqueta = 'dia'")



def Atribui_Validade(tipo):
    db.query("SELECT validade FROM Nuvem_medicao where tipo = '{}'".format(tipo))
    pesquisa = db.store_result()  # guarda o resultado da query
    resultado = pesquisa.fetch_row(how=1)
    bestb4 = resultado[0]["validade"].decode("utf-8")  # preciso de decodar os bytes para string
    if bestb4 == "1dia":
        validade_medicao = datetime.datetime.now() + datetime.timedelta(days=1)
    elif bestb4 == "1semana":
        validade_medicao = datetime.datetime.now() + datetime.timedelta(days=7)
    elif bestb4 == "1mes":  # para este eu preciso de fazer um truque
        validade_medicao = datetime.datetime.now().replace(
            day=1)  # primeiro tenho q buscar a data de hoje e meter para o dia 1
        validade_medicao += datetime.timedelta(
            days=32)  # depois eu adiciono 32 dias, para ter mesmo a certeza q avanco um mes
        try:
            validade_medicao = validade_medicao.replace(
                day=datetime.datetime.now().day)  # e retomo a por o dia do mes q esto presentemente
        except ValueError: #pode acontecer o seguinte: eu estar num mes com 31 dias e o outro mes so ter 3
            #vamos ao caso de fevereiro
            if validade_medicao.month == 2:
                if calendar.isleap(validade_medicao.year): # se for ano bisexto
                    validade_medicao = validade_medicao.replace(day=29) #fica 29 o dia
                else:
                    validade_medicao = validade_medicao.replace(day=28) #senao fica 28
            else: #se nao for fevereiro eu sei que vao ser outros meses com 30 dias
                validade_medicao = validade_medicao.replace(day=30)


    else:
        validade_medicao = datetime.datetime.now() + datetime.timedelta(
            days=365)  # 1ano se for ilimitado...

    return validade_medicao


#Calcula as medias consoante o contexto
def Faz_a_Media(what, db):
    mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe = 0, 0, 0, 0, 0, 0
    medicoes = ["temp", "humidade", "pressao", "ruido", "luz", "pessoas"]
    r_pesquisa = []
    if what == "minuto": #Se tou fazendo media de minutos vou dar uma rapada as valores do leitor para variaveis (buscado em loopleitor)
        for n in avgTemp:
            mediaT += n
        for n in avgHumid:
            mediaH += n
        for n in avgPres:
            mediaP += n
        for n in avgRuido:
            mediaR += n
        for n in avgLuz:
            mediaL += n
        for n in avgPessoas:
            mediaPe += n

        #Faco as respetivas contas
        mediaT = round(float(mediaT) / len(avgTemp), 1)
        mediaH = round(float(mediaH) / len(avgHumid), 1)
        mediaP = round(float(mediaP) / len(avgPres), 1)
        mediaR = round(float(mediaR) / len(avgRuido), 1)
        mediaL = round(float(mediaL) / len(avgLuz), 1)
        mediaPe = round(float(mediaPe) / len(avgPessoas), 1)
        #Nao limpa ainda e retorna no fim

    elif what == "hora": #Se vou fazer a media horaria 
        #Descricao da query: busca os valores medios, minimos e maximos de cada medicao juntando conforme os ids e etiquetas 
        for n in range(6):
            db.query("SELECT MAX(valor) as max, MIN(valor) as min, AVG(valor) as media from Nuvem_valor where etiqueta='minuto' and FK_Medicao_id in (SELECT id from Nuvem_medicao where tipo='{}')".format(medicoes[n]))

            pesquisa = db.store_result() #guarda o resultado da query
            resultado = pesquisa.fetch_row(how=1) #fetcha como dict
            r_pesquisa.append(resultado) #Detalhe: ele fetcha como dict mas insere em tuplos 
        maxT, minT, mediaT = float(r_pesquisa[0][0]["max"]), float(r_pesquisa[0][0]["min"]), float(r_pesquisa[0][0]["media"])
        maxH, minH, mediaH = float(r_pesquisa[1][0]["max"]), float(r_pesquisa[1][0]["min"]), float(r_pesquisa[1][0]["media"])
        maxP, minP, mediaP = float(r_pesquisa[2][0]["max"]), float(r_pesquisa[2][0]["min"]), float(r_pesquisa[2][0]["media"])
        maxR, minR, mediaR = float(r_pesquisa[3][0]["max"]), float(r_pesquisa[3][0]["min"]), float(r_pesquisa[3][0]["media"])
        maxL, minL, mediaL = float(r_pesquisa[4][0]["max"]), float(r_pesquisa[4][0]["min"]), float(r_pesquisa[4][0]["media"])
        maxPe, minPe, mediaPe = float(r_pesquisa[5][0]["max"]), float(r_pesquisa[5][0]["min"]), float(r_pesquisa[5][0]["media"])

        limpador(db, "minuto") #limpa os minutos para nao aparecerem a mais no ultima hora 
        return mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe, maxT, maxH, maxP, maxR, maxL, maxPe, minT, minH, minP, minR, minL, minPe
    elif what == "dia":
        for n in range(6):
            db.query("SELECT MAX(valor) as max, MIN(valor) as min, AVG(valor) as media from Nuvem_valor where etiqueta='hora' and FK_Medicao_id in (SELECT id from Nuvem_medicao where tipo='{}')".format(medicoes[n]))

            pesquisa = db.store_result() #guarda o resultado da query
            resultado = pesquisa.fetch_row(how=1)
            r_pesquisa.append(resultado)
        maxT, minT, mediaT = float(r_pesquisa[0][0]["max"]), float(r_pesquisa[0][0]["min"]), float(r_pesquisa[0][0]["media"])
        maxH, minH, mediaH = float(r_pesquisa[1][0]["max"]), float(r_pesquisa[1][0]["min"]), float(r_pesquisa[1][0]["media"])
        maxP, minP, mediaP = float(r_pesquisa[2][0]["max"]), float(r_pesquisa[2][0]["min"]), float(r_pesquisa[2][0]["media"])
        maxR, minR, mediaR = float(r_pesquisa[3][0]["max"]), float(r_pesquisa[3][0]["min"]), float(r_pesquisa[3][0]["media"])
        maxL, minL, mediaL = float(r_pesquisa[4][0]["max"]), float(r_pesquisa[4][0]["min"]), float(r_pesquisa[4][0]["media"])
        maxPe, minPe, mediaPe = float(r_pesquisa[5][0]["max"]), float(r_pesquisa[5][0]["min"]), float(
            r_pesquisa[5][0]["media"])

        limpador(db, "hora")
        limpador(db, "semana")#limpa ou nao os arquivos mais velhos q uma semana
        return mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe, maxT, maxH, maxP, maxR, maxL, maxPe, minT, minH, minP, minR, minL, minPe
    return mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe

#Loop principal que vai lendo os valores pelo leitor
def LoopLeitor(db, sensor1, sensor2):
    tempoM = datetime.datetime.now()
    tempoD = datetime.datetime.now()
    tempoS = datetime.datetime.now()
    medicoes = ["temp", "humidade", "pressao", "ruido", "luz", "pessoas"]
    nomes = ["Temperatura", "Humidade", "Pressao", "Ruido", "Luz", "Pessoas"]
    #datetime.strptime(medicao.get("timestamp", None), "%Y-%m-%d %H:%M:%S.%f")
    #select validade from Nuvem_medicao where tipo like "%relatorio%"


    while(True):
        t, h, p, r, l, pe = Leitor(sensor1, sensor2)
        avgTemp.append(t)
        avgHumid.append(h)
        avgPres.append(p)
        avgRuido.append(r)
        avgLuz.append(l)
        avgPessoas.append(pe)
        escritor(str(t),str(h),str(p),str(r),str(l),str(pe))
        if datetime.datetime.now().minute != tempoM.minute: #se ja se passou um minuto
            mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe = Faz_a_Media("minuto", db)
            valores = [mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe]
            for n in range(6):

                validade_medicao = Atribui_Validade(medicoes[n])
                pesquisa_seq = "(SELECT id from Nuvem_medicao where tipo  = '{}')".format(medicoes[n])
                db.query("INSERT INTO Nuvem_valor (valor, timestamp, etiqueta, FK_Medicao_id, validade) values ({}, '{}', '{}', {}, '{}')"
                         .format(valores[n], tempoM, "minuto", pesquisa_seq, validade_medicao))

            avgTemp.clear()
            avgPres.clear()
            avgHumid.clear()
            avgRuido.clear()
            avgLuz.clear()
            print("Minute Measure:\nAvgTemp={}\nAvgHumid={}\nAvgPres={}\nAvgRuido={}\nAvgLuz={}\nAvgPessoas={} \n\n".format(mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe))
            tempoM = datetime.datetime.now()


        if datetime.datetime.now().hour != tempoD.hour: #se ja se passou uma hora
            mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe, maxT, maxH, maxP, maxR, maxL, maxPe, minT, minH, minP, minR, minL, minPe = Faz_a_Media("hora", db)

            valores = [[mediaT, maxT, minT], [mediaH, maxH, minH], [mediaP, maxP, minP], [mediaR, maxR, minR], [mediaL, maxL, minL], [mediaPe, maxPe, minPe]]
            for n in range(6):
                validade_medicao = Atribui_Validade(medicoes[n])
                pesquisa_seq = "(SELECT id from Nuvem_medicao where tipo  = '{}')".format(medicoes[n])
                db.query("INSERT INTO Nuvem_valor (valor, timestamp, etiqueta, FK_Medicao_id, maximo, minimo, validade) values ({}, '{}', '{}', {}, {}, {}, '{}')"
                         .format(round(valores[n][0], 1), tempoD, "hora", pesquisa_seq, valores[n][1], valores[n][2], validade_medicao))

            print("Day Measure:\nAvgTemp={}\nAvgHumid={}\nAvgPres={}\nAvgRuido={}\nAvgLuz={}\nAvgPessoas={} \n\n".format(mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe))
            tempoD = datetime.datetime.now()

            # db.query("UPDATE Nuvem_medicao SET  where tipo like '%relatorio%'")
            db.query("select validade, tipo, unidade from Nuvem_medicao where tipo like '%relatorio%'")
            pesquisa = db.store_result()
            resultado = pesquisa.fetch_row(how=1, maxrows=0)
            data_proximo_relatorio = datetime.datetime.strptime(resultado[0]['validade'].decode('utf-8'),
                                                                "%Y-%m-%d %H:%M:%S.%f")

            validade_proximo_relatorio = resultado[0]['unidade'].decode('utf-8')
            quem_incluir_proximo_relatorio = resultado[0]['tipo'].decode('utf-8').split("-")[1]
            if datetime.datetime.now() >= data_proximo_relatorio: #Se ja se passou o tempo para gerar relatorio automats
                if validade_proximo_relatorio == "semana":
                    data_proximo_relatorio = datetime.datetime.now() + datetime.timedelta(days=7)
                elif validade_proximo_relatorio == "mes":
                    validade_medicao = datetime.datetime.now().replace(
                        day=1)  # primeiro tenho q buscar a data de hoje e meter para o dia 1
                    validade_medicao += datetime.timedelta(
                        days=32)  # depois eu adiciono 32 dias, para ter mesmo a certeza q avanco um mes
                    try:
                        validade_medicao = validade_medicao.replace(
                            day=datetime.datetime.now().day)  # e retomo a por o dia do mes q esto presentemente
                    except ValueError:  # pode acontecer o seguinte: eu estar num mes com 31 dias e o outro mes so ter 3
                        # vamos ao caso de fevereiro
                        if validade_medicao.month == 2:
                            if calendar.isleap(validade_medicao.year):  # se for ano bisexto
                                validade_medicao = validade_medicao.replace(day=29)  # fica 29 o dia
                            else:
                                validade_medicao = validade_medicao.replace(day=28)  # senao fica 28
                        else:  # se nao for fevereiro eu sei que vao ser outros meses com 30 dias
                            validade_medicao = validade_medicao.replace(day=30)
                    data_proximo_relatorio = validade_medicao
                elif validade_proximo_relatorio == "Nunca":
                    data_proximo_relatorio = datetime.datetime.now() + datetime.timedelta(days=365000)
                db.query("UPDATE Nuvem_medicao SET validade = '{}' where tipo like '%relatorio%'".format(data_proximo_relatorio))
                if float(getDiskSpaces("pfree")) > 10:
                    quem_incluir = []
                    if "T" in quem_incluir_proximo_relatorio: quem_incluir.append(medicoes[0])
                    if "H" in quem_incluir_proximo_relatorio: quem_incluir.append(medicoes[1])
                    if "P" in quem_incluir_proximo_relatorio: quem_incluir.append(medicoes[2])
                    if "R" in quem_incluir_proximo_relatorio: quem_incluir.append(medicoes[3])
                    if "L" in quem_incluir_proximo_relatorio: quem_incluir.append(medicoes[4])
                    if "p" in quem_incluir_proximo_relatorio: quem_incluir.append(medicoes[5])
                    lista_de_unidades = Lista_de_Unidades(db)
                    dados = []
                    prefacio = {
                        "automaticamente": True,
                        "tipo": validade_proximo_relatorio,
                        "quem_gerou": "Auto",
                    }

                    for n in quem_incluir:
                        validade = lista_de_unidades[n][1]
                        unidade = lista_de_unidades[n][0]
                        preservar_horas = lista_de_unidades[n][2]
                        texto_pesquisa = "SELECT * FROM Nuvem_valor WHERE etiqueta != 'minuto' and FK_Medicao_id in (SELECT id from Nuvem_medicao where tipo='{}') order by timestamp".format(
                            n)
                        db.query(texto_pesquisa)
                        pesquisa = db.store_result()
                        resultado = pesquisa.fetch_row(how=1, maxrows=0)
                        dados.append([nomes[medicoes.index(n)], validade, unidade, preservar_horas,
                                      resultado])

                    nome = datetime.datetime.now().strftime("%Y-%m-%d") + ".pdf"
                    caminho = PreparaPDF(dados, prefacio, nome, True)

                    db.query("select id from auth_user")
                    pesquisa = db.store_result()
                    ids_de_users = pesquisa.fetch_row(how=1, maxrows=0)

                    if validade_proximo_relatorio == "semana":
                        valiu = "seman"
                        os.system("mv {} root/semanal/{}".format(caminho,nome))
                        db.query("INSERT INTO Nuvem_ficheiro (nome, slug, timestamp, updated, tipo) values ('{}','{}','{}','{}','{}')".format(nome, nome.replace(".", "-"), datetime.datetime.now(), datetime.datetime.now(), "File"))

                        #db.query("INSERT INTO Nuvem_ficheiro_pasta (FK_dono_id, FK_ficheiro_filho_id,FK_pasta_parente_id) values ({},{},{})")
                    elif validade_proximo_relatorio == "mes":
                        valiu = "mensa"
                        os.system("mv {} root/mensal/{}".format(caminho, nome))
                        db.query("INSERT INTO Nuvem_ficheiro (nome, slug, timestamp, updated, tipo) values ('{}','{}','{}','{}','{}')".format(nome, nome.replace(".", "-"), datetime.datetime.now(), datetime.datetime.now(), "File"))


                    for n in ids_de_users:
                        db.query("INSERT INTO Nuvem_ficheiro_pasta (FK_dono_id, FK_ficheiro_filho_id,FK_pasta_parente_id) values ({},{},{})".format(n['id'], "(SELECT id FROM Nuvem_ficheiro WHERE nome like '%{}%' LIMIT 1)".format(nome), "(SELECT id FROM Nuvem_pasta WHERE caminho like '%{}%' LIMIT 1)".format(valiu)))


                    print("Novo relatorio gerado ({})".format(caminho))
                else:
                    print("Criaçao de relatorios suspensa pois o disco esta quase cheio!")





        if datetime.datetime.now().day != tempoS.day: #se ja se passou um dia
            mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe, maxT, maxH, maxP, maxR, maxL, maxPe, minT, minH, minP, minR, minL, minPe = Faz_a_Media("dia", db)

            valores = [[mediaT, maxT, minT], [mediaH, maxH, minH], [mediaP, maxP, minP], [mediaR, maxR, minR], [mediaL, maxL, minL], [mediaPe, maxPe, minPe]]
            for n in range(6):
                validade_medicao = Atribui_Validade(medicoes[n])
                pesquisa_seq = "(SELECT id from Nuvem_medicao where tipo  = '{}')".format(medicoes[n])
                db.query("INSERT INTO Nuvem_valor (valor, timestamp, etiqueta, FK_Medicao_id, maximo, minimo, validade) values ({}, '{}', '{}', {}, {}, {}, '{}')"
                         .format(round(valores[n][0], 1), tempoS, "dia", pesquisa_seq, valores[n][1], valores[n][2], validade_medicao))


            print("Week Measure:\nAvgTemp={}\nAvgHumid={}\nAvgPres={}\nAvgRuido={}\nAvgLuz={}\nAvgPessoas={} \n\n".format(mediaT, mediaH, mediaP, mediaR, mediaL, mediaPe))
            tempoS = datetime.datetime.now()


    


#Vai limpar todos os valores de medicoes que nao estejam na hora onde o server bootou, a fim de evitar problemas nas medicoes ao minuto 


if __name__ == '__main__':
    print("Conectando a base de dados com base nos campos definidos em DBData")
    data_base = getDBStuff()
    db = _mysql.connect(data_base["HOST"], data_base["USER"], data_base["PASSWORD"], data_base["NAME"])
    sys.stdout.write("Limpando medicoes de minuto desatualizadas")
    sys.stdout.flush()
    for n in range(5):
        sys.stdout.write(".")
        sleep(0.3)
        sys.stdout.flush()
    limpador(db, "minuto") #some com tudo do ultima hora q nao seja da hora q isto arranca
    limpador(db, "hora")
    print("conectado e limpo!\n\n")
    Sensor1 = Arduino()
    Sensor2 = SenseHat()

    print("Iniciando as leituras...")
    try:
        LoopLeitor(db, Sensor1, Sensor2)
            
    except KeyboardInterrupt:
        print("Desconectando da base de dados...")
