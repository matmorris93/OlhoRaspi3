#ifndef DisplaySegmentos_h
#define DisplaySegmentos_h

#include "Arduino.h"

class SeteSegmentos
{
    public:
        SeteSegmentos(int* segmentos);
        void Escreve(int digito);
        void WritePonto(int dp);
        void LimpaDisplay();
    private:
        int pinos[8];
        
};


#endif
