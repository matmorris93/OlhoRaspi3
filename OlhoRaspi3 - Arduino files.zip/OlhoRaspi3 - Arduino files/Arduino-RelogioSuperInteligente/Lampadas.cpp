#include "Arduino.h"
#include "Lampadas.h"


Lamp::Lamp(int porta, int tipo)
{
    pino = porta;
    tipe = tipo;
    if(tipo==0)
    brilho = 0;
    else
    brilho = 255;
    pinMode(pino, OUTPUT);
}


void Lamp::Interruptor(int shine)
{
  if(shine <=0)
  {
    brilho=0;
    estado = 0; 
  }
  else if(shine > 255)
  {
    brilho = 255;
    estado = 1;
  }
  else
  {
    brilho = shine;
    estado = 1;
  }
  if(tipe ==1)
      brilho = 255-shine;
  
  analogWrite(pino, brilho);
    
}
