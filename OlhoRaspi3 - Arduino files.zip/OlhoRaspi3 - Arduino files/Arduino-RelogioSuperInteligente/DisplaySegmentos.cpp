#include "Arduino.h"
#include "DisplaySegmentos.h"


SeteSegmentos::SeteSegmentos(int* segmentos)
{
    for(int i=0; i<8;i++)
    {
        pinos[i] = segmentos[i];
        pinMode(pinos[i], OUTPUT);
    }
}

void SeteSegmentos::LimpaDisplay()
{
    for(int i=0; i<8;i++)
    {
        digitalWrite(pinos[i], HIGH);
    }
    
}

void SeteSegmentos::Escreve(int i)
{
  LimpaDisplay();
  if(i == 0)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
  }
  else if(i == 1)
  {
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
  }
  else if(i == 2)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 3)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 4)
  {
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 5)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 6)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 7)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
  }
  else if(i == 8)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 9)
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
  }
  else if(i == 10) //A 
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
    
  }
  else if(i == 11) //d de data
  {
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[6], LOW);
   
  }
  else if(i == 12) //e
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
    
  }
  else if(i == 13) //f 
  {
    digitalWrite(pinos[0], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
    
  }
  else if(i == 14) //H de hora
  {
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
    
  }
  else if(i == 15) //r
  {
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[6], LOW);
    
  }
  else if(i == 16) //t
  {
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    digitalWrite(pinos[6], LOW);
    
  }
  else if(i == 17) //u
  {
    digitalWrite(pinos[1], LOW);
    digitalWrite(pinos[2], LOW);
    digitalWrite(pinos[3], LOW);
    digitalWrite(pinos[4], LOW);
    digitalWrite(pinos[5], LOW);
    
  }
}


void SeteSegmentos::WritePonto(int dp)
{
    if(dp == 1)
	{
		digitalWrite(pinos[7], LOW);
	}
	else 
	{
		digitalWrite(pinos[7], HIGH);
	}
}
