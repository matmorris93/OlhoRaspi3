#ifndef Lampadas_h
#define Lampadas_h

#include "Arduino.h"

class Lamp
{
    public:
        Lamp(int porta, int tipo);
        void Interruptor(int shine);
    private:
        int brilho;
        int pino;
        int estado;
        int tipe;
        
};


#endif
